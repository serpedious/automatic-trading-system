from __future__ import print_function

def lambda_handler(event, context):
    print("hoge")